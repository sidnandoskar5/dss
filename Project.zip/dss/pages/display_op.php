<?php
function getAllMedia(){
    $userID = trim($_GET['udi']);
    $orientation = trim($_GET['ort']);
    $audience = '1';

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT 
                media.id, 
                media.filename, 
                media.filetype, 
                media.ogname, 
                media.orientation, 
                media.audience, 
                audience.type, 
                media.userid 
            FROM 
                media 
            INNER JOIN 
                audience 
            ON 
                media.audience = audience.id
            WHERE 
                media.status = '1' 
            AND media.userid = '$userID'
            AND media.orientation = '$orientation'
            AND media.audience = '$audience'
            LIMIT 1;";
    
    $result = $conn->query($sql);

    $data = [];

    if(!empty($result) && $result->num_rows > 0){
        while($row = $result->fetch_assoc()) {
            $data = $row;
            break;
        }
    }

    $conn->close();

    return $data;
}

$media = getAllMedia();
?>


<script src="./assets/js/face-api.js"></script>
<script src="./assets/js/display.js"></script>
<style>
    .overlay{display:none;z-index:0}
    .overlay.active{width:100%;height:100%;position:fixed;top:0;left:0;z-index:9;display:flex;align-items:center;justify-content:center;background:#fff;font-size:32px;font-weight:bold}
    .ed-pannel{max-width:767px;margin:20px auto;padding:20px}
    .ed img{max-width:100%;height:auto}
    .ed-img-wrapper{border: 1px solid #ccc;padding:10px;}
    .ed-img-wrapper.landscape{width:100%;aspect-ratio:16/9}
    .base{position:relative;height:120px;width:100%;display:flex;gap: 30px; align-items:center}
    .faceinfo div{margin:0 0 10px}
    .tlabel{font-weight:bold}
    .heading{margin:0 0 15px;}
</style>
<span 
    id="display-info"
    data-displayname = <?php echo !empty(trim($_GET['d_name'])) ? trim($_GET['d_name']) : ''; ?>
    data-displaykey = <?php echo !empty(trim($_GET['key'])) ? trim($_GET['key']) : ''; ?>
    data-user = <?php echo !empty(trim($_GET['udi'])) ? trim($_GET['udi']) : ''; ?>
    data-orientation = <?php echo !empty(trim($_GET['ort'])) ? trim($_GET['ort']) : ''; ?>
></span>
<div id="err-overlay" class="overlay"></div>

<div class="ed-pannel">
    <div class="heading">Ad Results for: 
        <span id="results-for">
            <span id="audience"><span class="tlabel">Audience:</span> <span id="tval"><?php echo ucfirst($media['type']); ?></span></span>&nbsp;
            <span id="orientation"><span class="tlabel">Orientation:</span> <span id="tval"><?php echo ucfirst($media['orientation']); ?></span></span>
        </span>
    </div>
    <div id="ed" class="ed">
        <?php if(!empty($media)){ ?>
            <figure class="ed-img-wrapper <?php echo $media['orientation']; ?>"><img src="<?php echo 'uploads/' . $media['ogname'] . '.' . $media['filetype']; ?>" alt="<?php echo $media['filename']; ?>"></figure>
        <?php } ?>
    </div>
    <div class="base">
        <video id="video" width="100" height="100" autoplay muted></video>
        <div id="faceinfo" class="faceinfo">
            <div>
                <span class="tlabel">Gender:</span>
                <span id="gender">Rendering....</span>
            </div>
            <div>
                <span class="tlabel">Age:</span>
                <span id="age">Rendering....</span>
            </div>
        </div>
    </div>
</div>