<?php
global $conn;
$error = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    function isValidated(){
        if(empty(trim($_POST['uname'])) || empty(trim($_POST['email'])) || empty(trim($_POST['pswd'])) || empty(trim($_POST['rpswd'])) || (trim($_POST['pswd']) !== trim($_POST['rpswd']))){
            return false;
        }
        return true;
    }

    function checkUserExist(){
        global $conn;
        $username = trim($_POST['uname']);
        $email = trim($_POST['email']);

        $sql = "SELECT username, email FROM user WHERE username='$username' or email='$email'";
        $result = $conn->query($sql);

        if($result->num_rows > 0){
            $ermsgs = '';
            while($row = $result->fetch_assoc()) {
                if($row['username'] == $username){
                    $ermsgs .= '<p>Username is already exists.</p>';
                }

                if($row['email'] == $email){
                    $ermsgs .= '<p>Email is already exists.</p>';
                }
            }

            return ['status' => false, 'msg' => $ermsgs];

        }
        return ['status' => true];
    }

    if(isValidated()){
        if(checkUserExist()['status']){
            $username = trim($_POST['uname']);
            $email = trim($_POST['email']);
            $pass = trim($_POST['pswd']);
            $repass = MD5(trim($_POST['rpswd']));
    
            try{
                $sql = "INSERT INTO user(username, email, password)
                VALUES ('$username', '$email', '$repass')";
                
                if ($conn->query($sql) === TRUE) {
                    $last_id = $conn->insert_id;
                    header("Location: http://localhost/dss/?p=login");
                } else {
                    $error = "Error: " . $conn->error;
                }
            }catch(Exception $err){
                $error = "Error: " . $err->getMessage();
            }
        }else{
            $error = checkUserExist()['msg'];
        }
    }else{
        $error = "Error: Fill all values correctly.";
    }
}
?>

<div class="register center">
    <div class="container">
        <div class="form-wrapper">
            <div class="card">
                <div class="card-header">Register</div>
                <div class="card-body">
                    <form action="/dss/?p=register" class="needs-validation" method="post">
                        <div class="mb-3 mt-3">
                            <label for="uname" class="form-label">Username:</label>
                            <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" minlength=5 maxlength=20 required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter Email Address" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$" required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" minlength=3 maxlength=60 required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Re-enter Password:</label>
                            <input type="password" class="form-control" id="repwd" placeholder="Re-enter password" name="rpswd" minlength=3 maxlength=60 required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="myCheck" name="remember" required>
                            <label class="form-check-label" for="myCheck">I agree.</label>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Check this checkbox to continue.</div>
                        </div>
                        <?php if(!empty($error)){ echo "<div class='error'>$error</div>"; } ?>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
                <div class="card-footer login-options">
                    <a href="/dss/?p=login" class="forgot-link">Go to Login</a>
                </div>
            </div>
        </div>
    </div>
</div>