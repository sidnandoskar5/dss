<?php
function getAllDisplay(){
    $userID = $_SESSION['user']['id'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT 
                id,
                name, 
                displaykey, 
                displayurl, 
                orientation,
                status
            FROM 
                display
            WHERE 
                userid = $userID";
    
    $result = $conn->query($sql);

    $conn->close();

    return $result;
}

$displays = getAllDisplay();
?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
    .edit-content, .delete-content{
        background: transparent;
        border:0;
        outline:0;
    }
</style>

<h2 class="page-title">
    Displays
</h2>

<?php if(!empty($displays) && $displays->num_rows > 0){ ?>
<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Display</th>
                <th>Display Key</th>
                <th>Display URL</th>
                <th>Orientation</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="gallery">
            <?php while($row = $displays->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['displaykey']; ?></td>
                <td><?php echo '/dss' . $row['displayurl']; ?></td>
                <td><?php echo $row['orientation']; ?></td>
                <td><?php echo $row['status'] == 1 ? 'Active' : 'Inactive'; ?></td>
                <td>
                    <div class="btn-flx">
                        <button 
                            data-id="<?php echo $row['id']; ?>"
                            data-display="<?php echo $row['name']; ?>"
                            data-key="<?php echo $row['displaykey']; ?>"
                            data-url="<?php echo $row['displayurl']; ?>"
                            data-orientation="<?php echo $row['orientation']; ?>"
                            data-status="<?php echo $row['status']; ?>"
                            class="edit-content glyphicon glyphicon-edit" 
                            data-toggle="modal" 
                            data-target="#editModal">
                        </button>
                        <button 
                            data-id="<?php echo $row['id']; ?>"
                            class="delete-content trash-content glyphicon glyphicon-trash">
                        </button>
                    </div>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php }else{ ?>
    <div class="message">No displays are registered.</div>
<?php } ?>

<div id="editModal" class="modal fade" role="dialog">  
    <div class="modal-dialog">  
        <div class="modal-content">  
            <div class="modal-header">
                <h4 class="modal-title">Edit Display</h4>
            </div>
            <div class="modal-body">  
                <form method="post" id="edit_form">
                    <div class="form-group mb-3">
                        <label class="form-label" for="ednewFileName">Display Name:</label>
                        <input class="form-control" type="text" name="newDisplayName" id="ednewFileName" placeholder="New file name" required/>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="edorientation">Orientation:</label>
                        <select class="form-select" name="orientation" id="edorientation" required>
                            <option value="landscape">Landscape</option>
                            <option value="portrait">Portrait</option>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="edstatus">Status:</label>
                        <select class="form-select" name="status" id="edstatus" required>
                            <option value="0">Inactive</option>
                            <option value="1">Active</option>
                        </select>
                    </div>
                    <input type="hidden" id="eddisplayid" name="displayid">
                    <input type="hidden" name="req-type" value="update">
                    <input type="hidden" name="userid" value="<?php echo $_SESSION['user']['id']; ?>">
                    <button class="btn btn-primary" type="submit">Update</button>
                </form>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div> 

<script>
    $(document).ready(function(){
        $(document).on("click", ".edit-content", function(e){
            const $this = $(this);
            const id = $this.data('id');
            const display = $this.data('display');
            const orientation = $this.data('orientation');
            const status = $this.data('status');

            $("#ednewFileName").val(display);
            $("#edorientation").val(orientation);
            $("#edstatus").val(status);
            $("#eddisplayid").val(id);
        });

        $(document).on("submit","#edit_form", function(e){
            e.preventDefault();  
            var this_data = new FormData(this)
            $.ajax({  
                url :"/dss/util/handle_display.php",
                method:"POST",  
                data:new FormData(this),  
                contentType:false,
                processData:false,  
                success:function(data){  
                    let udata = JSON.parse(data);
                    if(udata.status){
                        location.reload();
                    }
                }  
            })  
        });
    });
</script>