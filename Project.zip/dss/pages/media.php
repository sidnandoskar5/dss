<?php
function getAllMedia(){
    $userID = $_SESSION['user']['id'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT 
                media.id, 
                media.filename, 
                media.filetype, 
                media.ogname, 
                media.orientation, 
                media.audience, 
                audience.type, 
                media.userid 
            FROM 
                media 
            INNER JOIN 
                audience 
            ON 
                media.audience = audience.id
            WHERE 
                media.status = 1 
            AND media.userid = $userID;";
    
    $result = $conn->query($sql);

    $conn->close();

    return $result;
}

$media = getAllMedia();

?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
    .edit-content, .delete-content{
        background: transparent;
        border:0;
        outline:0;
    }

    .tbl-img{
        width: 100px;
        height: 100px;
        max-width:100%;
        margin:0 auto;
    }
    

    .tbl-img img{
        height: 100%;
        -o-object-fit: contain;
        object-fit: contain;
        -o-object-position: center;
        object-position: center;
        width: 100%;
    }
</style>
<h2 class="page-title">
    Media Gallery
    <button type="button" class="btn btn-primary add-media" data-toggle="modal" data-target="#uploadModal">Add Media</button>
</h2>
<?php if(!empty($media) && $media->num_rows > 0){ ?>
<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Media</th>
                <th>File Name</th>
                <th>Type</th>
                <th>Orientation </th>
                <th>Target</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="gallery">
            <?php while($row = $media->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><figure class="tbl-img"><img src="<?php echo 'uploads/' . $row['ogname'] . '.' . $row['filetype']; ?>" alt="<?php echo $row['filename']; ?>"></figure></td>
                <td><?php echo $row['filename']; ?></td>
                <td><?php echo $row['filetype']; ?></td>
                <td><?php echo $row['orientation']; ?></td>
                <td><?php echo $row['type']; ?></td>
                <td>
                    <div class="btn-flx">
                        <button 
                            data-id="<?php echo $row['id']; ?>"
                            data-filename="<?php echo $row['filename']; ?>"
                            data-filetype="<?php echo $row['filetype']; ?>"
                            data-orientation="<?php echo $row['orientation']; ?>"
                            data-type="<?php echo $row['type']; ?>"
                            data-typeid="<?php echo $row['audience']; ?>"
                            class="edit-content glyphicon glyphicon-edit" 
                            data-toggle="modal" 
                            data-target="#editModal">
                        </button>
                        <button 
                            data-id="<?php echo $row['id']; ?>"
                            class="delete-content trash-content glyphicon glyphicon-trash">
                        </button>
                    </div>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php }else{ ?>
    <div class="message">No media available. <a style="color:blue;cursor:pointer;" data-toggle="modal" data-target="#uploadModal">Click here</a> to add Media</div>
<?php } ?>

<div id="uploadModal" class="modal fade" role="dialog">  
    <div class="modal-dialog">  
        <div class="modal-content">  
            <div class="modal-header">
                <h4 class="modal-title">Add Media</h4>
            </div>
            <div class="modal-body">  
                <form method="post" id="upload_form">
                    <div class="form-group mb-3">
                        <label class="form-label" for="select_image">Select Media File:</label>
                        <input class="form-control" type="file" name="images[]" id="select_image" required/>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="newFileName">Filename:</label>
                        <input class="form-control" type="text" name="newFileName" id="newFileName" placeholder="New file name" required/>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="audience">Target Audience:</label>
                        <select class="form-select" name="audience" id="audience" required>
                            <option value="1">All</option>
                            <option value="2">Men</option>
                            <option value="3">Women</option>
                            <option value="4">Boys</option>
                            <option value="5">Girls</option>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="orientation">Orientation:</label>
                        <select class="form-select" name="orientation" id="orientation" required>
                            <option value="landscape">Landscape</option>
                            <option value="portrait">Portrait</option>
                        </select>
                    </div>
                    <input type="hidden" name="role" value="new">
                    <input type="hidden" name="userid" value="<?php echo $_SESSION['user']['id']; ?>">
                    <button class="btn btn-primary" type="submit">Upload</button>
                    <p id="umsg" class="error"></p>
                </form>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div id="editModal" class="modal fade" role="dialog">  
    <div class="modal-dialog">  
        <div class="modal-content">  
            <div class="modal-header">
                <h4 class="modal-title">Edit Media</h4>
            </div>
            <div class="modal-body">  
                <form method="post" id="edit_form">
                    <div class="form-group mb-3">
                        <img src="/" alt="">
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="ednewFileName">Filename:</label>
                        <input class="form-control" type="text" name="newFileName" id="ednewFileName" placeholder="New file name" required/>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="edaudience">Target Audience:</label>
                        <select class="form-select" name="audience" id="edaudience" required>
                            <option value="1">All</option>
                            <option value="2">Men</option>
                            <option value="3">Women</option>
                            <option value="4">Boys</option>
                            <option value="5">Girls</option>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="edorientation">Orientation:</label>
                        <select class="form-select" name="orientation" id="edorientation" required>
                            <option value="landscape">Landscape</option>
                            <option value="portrait">Portrait</option>
                        </select>
                    </div>
                    <input type="hidden" id="edmediaid" name="mediaid">
                    <input type="hidden" id="edfiletype" name="filetype">
                    <input type="hidden" name="role" value="update">
                    <input type="hidden" name="userid" value="<?php echo $_SESSION['user']['id']; ?>">
                    <button class="btn btn-primary" type="submit">Update</button>
                    <p id="emsg" class="error"></p>
                </form>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div> 

<script>  
 $(document).ready(function(){  
    $('#upload_form').on('submit', function(e){  
        e.preventDefault();  
        var this_data = new FormData(this)
        $.ajax({  
            url :"/dss/util/uploads.php",
            method:"POST",  
            data:new FormData(this),  
            contentType:false,  
            processData:false,  
            success:function(data){  
                let udata = JSON.parse(data);
                if(udata.status){
                    $('#select_image, #newFileName, #audience, #orientation').val('');  
                    $("#umsg").removeClass('error').addClass('success').html(udata.message);
                    $('#gallery').append(udata.data);
                }else{
                    $("#umsg").html(udata.message);
                }
            }  
        })  
    });

    $(document).on('click', '.edit-content', function(){
        let $this = $(this);
        let id = $this.data('id');
        let filename = $this.data('filename');
        let filetype = $this.data('filetype');
        let orientation = $this.data('orientation');
        let type = $this.data('type');
        let typeid = $this.data('typeid');

        $("#ednewFileName").val(filename);
        $("#edaudience").val(typeid);
        $("#edorientation").val(orientation);
        $("#edmediaid").val(id);
        $("#edfiletype").val(filetype);
    });

    $('#edit_form').on('submit', function(e){  
        e.preventDefault();  
        var this_data = new FormData(this)
        $.ajax({  
            url :"/dss/util/uploads.php",
            method:"POST",  
            data:new FormData(this),  
            contentType:false,
            processData:false,  
            success:function(data){  
                let udata = JSON.parse(data);
                if(udata.status){
                    location.reload();
                }else{
                    $("#emsg").html(udata.message);
                }
            }  
        })  
    });

    $(document).on('click', '.edit-content', function(){
        let $this = $(this);
        let id = $this.data('id');
        let filename = $this.data('filename');
        let filetype = $this.data('filetype');
        let orientation = $this.data('orientation');
        let type = $this.data('type');
        let typeid = $this.data('typeid');

        $("#ednewFileName").val(filename);
        $("#edaudience").val(typeid);
        $("#edorientation").val(orientation);
        $("#edmediaid").val(id);
        $("#edfiletype").val(filetype);
    });

    $(document).on('click', '.delete-content', function(){
        let $this = $(this);
        let id = $this.data('id');

        $.post("/dss/util/uploads.php",
            {id: id, role: 'delete', userid: <?php echo $_SESSION['user']['id']; ?>},
            function(data, status){
                let udata = JSON.parse(data);
                if(udata.status){
                    location.reload();
                }
            }
        );
    });

 });  
 </script>  