<?php
global $conn;
$error = "";

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    function isValidated(){
        if(empty(trim($_POST['uname'])) || empty(trim($_POST['pswd']))){
            return false;
        }
        return true;
    }

    function checkUserExist(){
        global $conn;
        $username = trim($_POST['uname']);
        $password = trim($_POST['pswd']);

        $sql = "SELECT id, username, email FROM user WHERE username='$username' AND password ='" . MD5($password) . "'";
        $result = $conn->query($sql);

        if($result->num_rows > 0){
            $ermsgs = '';
            while($row = $result->fetch_assoc()) {
                $_SESSION['user'] = [
                    'id' => $row['id'],
                    'username' => $row['username'],
                    'email' => $row['email']
                ];
            }

            return ['status' => true];

        }
        return ['status' => false];
    }

    if(isValidated()){
        if(checkUserExist()['status']){
            header("Location: http://localhost/dss/?p=home");
        }else{
            $error = "Error: Credentials does not match.";
        }
    }else{
        $error = "Error: Fill all values correctly.";
    }
}

if($_SERVER['REQUEST_METHOD'] === 'GET'){
    session_unset();
    session_destroy();
}

?>

<div class="login center">
    <div class="container">
        <div class="form-wrapper">
            <div class="card">
                <div class="card-header">Login</div>
                <div class="card-body">
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="needs-validation" method="post">
                        <div class="mb-3 mt-3">
                            <label for="uname" class="form-label">Username:</label>
                            <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <?php if(!empty($error)){ echo "<div class='error'>$error</div>"; } ?>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
                <div class="card-footer login-options">
                    <a href="/dss/?p=forgot" class="forgot-link">Forgot password?</a>
                    <a href="/dss/?p=register" class="register-link">Register a new user.</a>
                </div>
            </div>
        </div>
    </div>
</div>