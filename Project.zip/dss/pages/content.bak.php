<div class="container">  
    <h2 class="title">Content Gallery</h2>
    <div id="gallery" class="row">
        <?php  
            $images = glob("uploads/*.*");
            foreach($images as $image)  
            {  
                echo '<div class="col-md-2">
                <div class="img-wrapper">
                    <img src="' . $image .'" />
                </div>
                </div>';  
            }  
        ?>  
    </div>
</div>
<div id="uploadModal" class="">  
    <div class="modal-dialog">  
        <div class="modal-content">  
            <div class="modal-body">  
                <form method="post" id="upload_form">  
                    <label>Select Multiple Image</label>  
                    <input type="file" name="images[]" id="select_image" />  
                </form>  
            </div>  
        </div>  
    </div>  
</div>

<script>  
 $(document).ready(function(){  
      $('#select_image').change(function(){3  
           $('#upload_form').submit();  
      });  
      $('#upload_form').on('submit', function(e){  
           e.preventDefault();  
            var this_data = new FormData(this)
           console.log(e);

           $.ajax({  
                url :"/util/uploads.php",
                method:"POST",  
                data:new FormData(this),  
                contentType:false,  
                processData:false,  
                success:function(data){  
                    console.log(data);
                    //  $('#select_image').val('');  
                    //  $('#uploadModal').modal('hide');  
                    //  $('#gallery').html(data);  
                }  
           })  
      });  
 });  
 </script>  