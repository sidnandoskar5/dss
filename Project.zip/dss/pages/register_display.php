<?php



?>

<style>
    .notice{
        margin:10px 0;
        font-size: 15px;
        line-height: 30px;
        text-align:center;
    }
</style>

<div class="display-register center">
    <div class="container">
        <div id="reg-form" class="form-wrapper">
            <div class="card">
                <div class="card-header">Register Display</div>
                <div class="card-body">
                    <form method="post" id="upload_form">
                        <div class="mb-3 mt-3">
                            <label for="uname" class="form-label">Username:</label>
                            <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Display Name:</label>
                            <input type="text" class="form-control" id="dispname" placeholder="Display Name" name="dispname" required>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Please fill out this field.</div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="orientation">Orientation:</label>
                            <select class="form-select" name="orientation" id="orientation" required>
                                <option value="landscape">Landscape</option>
                                <option value="portrait">Portrait</option>
                            </select>
                        </div>
                        <input type="hidden" name="displaykey" id="displaykey">
                        <input type="hidden" name="req-type" id="register" value="register">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="notice">
            <p id="resp-msg"></p>
            <p id="link"></p>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        let dispinfo = JSON.parse(localStorage.getItem("dispinfo"));
        if(dispinfo){
            checkDisplayStatus(dispinfo);
        }

        function checkDisplayStatus(dispinfo){
            const displayId = dispinfo.id;
            const params = new URLSearchParams(dispinfo.url);
            const uid = params.get('udi');

            $.post("/dss/util/handle_display.php",
                {displayId, uid, 'req-type': 'expiry'},
                function(data, status){
                    let stat = false;
                    if(status){
                        let udata = JSON.parse(data);
                        stat = udata.status;
                        if(!stat){
                            $("#resp-msg").html("This display is Expired.");
                            dispinfo.status=0;
                            localStorage.setItem("dispinfo",JSON.stringify(dispinfo));
                        }else{
                            $("#resp-msg").html("This display is already registered.");
                            $("#link").html(`<a href="/dss${dispinfo.url}">Click Here to Start Showing Ads.</a>`);
                            $("#reg-form").hide();
                        }
                    }
                }
            );
        }

        $("#displaykey").val(generateRandomKey());
        function generateRandomKey() {
            const chars = '0123456789';
            let key = '';
            for (let i = 0; i < 10; i++) {
                key += chars[Math.floor(Math.random() * chars.length)];
            }
            return key;
        }
        $("#upload_form").on('submit', function(e){
            e.preventDefault();
            let dispinfo = JSON.parse(localStorage.getItem("dispinfo"));
            if(dispinfo){
                $("#resp-msg").html("This display is already registered.");
                $("#link").html(`<a href="/dss${dispinfo.url}">Click Here to Start Showing Ads.</a>`);
                return false;
            }
            var this_data = new FormData(this)
            var displayKey = $("#displaykey").val();
            $.ajax({  
                url :"/dss/util/handle_display.php",
                method:"POST",  
                data:new FormData(this),  
                contentType:false,
                processData:false,  
                success:function(data){  
                    let udata = JSON.parse(data);
                    $("#resp-msg").html(udata.message);
                    if(udata.status){
                        udata.data.status = 1;
                        localStorage.setItem("dispinfo", JSON.stringify(udata.data));
                        $("#link").html(`<a href="/dss${udata.data.url}">Click Here to Start Showing Ads.</a>`);
                    }
                }  
            })  
        })
    });
</script>