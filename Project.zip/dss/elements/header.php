<header class="header">
    <div class="container-fluid">
        <div class="header-wrapper">
            <h1 class="logo"><a href="/">DSS</a></h1>
            <div class="user-info">
                <span>Howdy, <span id="user"><?php echo strtoupper($_SESSION['user']['username']); ?></span></span>
                <a class="logout" href="/dss/?p=logout">Logout</a>
            </div>
        </div>
    </div>
</header>