<?php
if(!empty($_GET['p']) && !in_array($_GET['p'],['login','register','forgot'])){
$currentPage = $_GET['p'];
$menu = [
    [
        'label' => 'Dashboard',
        'page' => 'home',
    ],
    [
        'label' => 'Media',
        'page' => 'media',
    ],
    [
        'label' => 'Display',
        'page' => 'display',
    ],
    [
        'label' => 'Schedule',
        'page' => 'schedule',
    ],
];
?>

<nav>
    <ul>
        <?php foreach($menu as $page){ ?>
        <li class="<?php echo $currentPage === $page['page'] ? 'active' : ''; ?>">
            <a href="/dss/?p=<?php echo $page['page']; ?>"><?php echo $page['label']; ?></a>
        </li>
        <?php } ?>
    </ul>
</nav>

<?php } ?>