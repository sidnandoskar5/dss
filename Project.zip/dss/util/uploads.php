<?php
    $newId = null;
    $userId = $_POST['userid'];
    $audienceType = [
        '1' => 'all',
        '2' => 'men',
        '3' => 'women',
        '4' => 'boys',
        '5' => 'girls',
    ];

    if($_POST['role'] === 'new'){
        if(is_array($_FILES)){
            foreach($_FILES['images']['name'] as $name => $value)  
            {  
                $fileName = explode(".", $_FILES['images']['name'][$name]);  
                $newFileName = $_POST['newFileName'];
                $targetAudience = $_POST['audience'];
                $orientation = $_POST['orientation'];
                $allowed_extension = array("jpg", "jpeg", "png", "gif");
               
                if(in_array($fileName[1], $allowed_extension)){  
                    if(!checkDuplicateName($newFileName, $fileName[1], 0, $userId)){
                        echo json_encode([
                            'status' => false,
                            'message' => 'Media name already exists.'
                        ]);
        
                        exit(0);
                    }
    
                    $id = makeDBEntry($newFileName, $targetAudience, $fileName[1], $userId, $orientation, $fileName[0]);
                    if(!$id){
                        echo json_encode([
                            'status' => false,
                            'message' => 'Failed to make an entry.'
                        ]);
    
                        exit(0);
                    }
                    
                    $sourcePath = $_FILES["images"]["tmp_name"][$name];  
                    $targetPath = "../uploads/" . $fileName[0] ."." . $fileName[1];
                    move_uploaded_file($sourcePath, $targetPath);
    
                    echo json_encode([
                        'status' => true,
                        'message' => 'Media added successfully.',
                        'data' => generateHTML([
                            'id' => $id,
                            'ogname' => $fileName[0],
                            'filename' => $newFileName,
                            'filetype' => $fileName[1],
                            'orientation' => $orientation,
                            'type' => $audienceType[$targetAudience],
                            'audience' => $targetAudience
                        ])
                    ]);
                }  
            }
        }
    }elseif($_POST['role'] === 'update'){
        $newFileName = $_POST['newFileName'];
        $targetAudience = $_POST['audience'];
        $orientation = $_POST['orientation'];
        $mediaid = $_POST['mediaid'];
        $filetype = $_POST['filetype'];

        if(!checkDuplicateName($newFileName, $filetype, $mediaid, $userId)){
            echo json_encode([
                'status' => false,
                'message' => 'Media name already exists.'
            ]);

            exit(0);
        }

        if(updateMediaInfo($newFileName, $targetAudience, $orientation, $mediaid, $filetype)){
            echo json_encode([
                'status' => true,
                'message' => 'Media name updated successfully.'
            ]);

            exit(0);
        }
        
        echo json_encode([
            'status' => false,
            'message' => 'Something went wrong.'
        ]);

        exit(0);
    }elseif($_POST['role'] === 'delete'){
        $id = $_POST['id'];

        if(deleteMedia($id)){
            echo json_encode([
                'status' => true,
                'message' => 'Media name updated successfully.'
            ]);

            exit(0);
        }

        echo json_encode([
            'status' => false,
            'message' => 'Something went wrong.'
        ]);

        exit(0);
    }

    function deleteMedia($id){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dss";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "UPDATE media SET status=0 WHERE id=$id";
        $status = $conn->query($sql);
        $conn->close();
        return $status;
    }

    function updateMediaInfo($newFileName, $targetAudience, $orientation, $mediaid, $filetype){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dss";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "UPDATE media SET filename='$newFileName', audience='$targetAudience', orientation='$orientation' WHERE id=$mediaid";
        $status = $conn->query($sql);
        $conn->close();
        return $status;
    }

    function checkDuplicateName($fileName, $type, $mediaid, $userId){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dss";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT id 
                FROM media 
                WHERE 
                    filename='$fileName' 
                AND filetype='$type'
                AND userid=$userId
                AND id != $mediaid";
                
        $result = $conn->query($sql);

        $conn->close();

        if($result->num_rows > 0){
            return false;
        }

        return true;
    }

    function generateHTML($data){
        $html = '<tr>
            <td>' . $data["id"] . '</td>
            <td>
            <figure class="tbl-img">
            <img src="uploads/' . $data["ogname"] . '.' . $data["filetype"] . '" alt="' . $data["filename"] . '">
            </figure>
            </td>
            <td>' . $data["filename"] . '</td>
            <td>' . $data["filetype"] . '</td>
            <td>' . $data["orientation"] . '</td>
            <td>' . $data["type"] . '</td>
            <td>
                <div class="btn-flx">
                    <button 
                        data-id="' . $data["id"] . '"
                        data-filename="' . $data["filename"] . '"
                        data-filetype="' . $data["filetype"] . '"
                        data-orientation="' . $data["orientation"] . '"
                        data-type="' . $data["type"] . '"
                        data-typeid="' . $data["audience"] . '"
                        class="edit-content glyphicon glyphicon-edit" 
                        data-toggle="modal" 
                        data-target="#editModal">
                    </button>
                    <button 
                        data-id="' . $data["id"] . '" 
                        class="delete-content trash-content glyphicon glyphicon-trash">
                    </button>
                </div>
            </td>
        </tr>';

        return $html;
    }

    function makeDBEntry($name, $audience, $type, $userId, $orientation, $ogname){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dss";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        try{
            $sql = "INSERT INTO media(filename, filetype, audience, userid, orientation, ogname)
            VALUES ('$name', '$type', '$audience', '$userId', '$orientation', '$ogname')";
            
            if ($conn->query($sql) === TRUE) {
                $newId = $conn->insert_id;
                
                $conn->close();
                return $newId;
            } else {
                return false;
            }
        }catch(Exception $err){
            return false;
        }
    }