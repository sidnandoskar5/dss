<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    function getAllMedia(){
        $userID = trim($_POST['userId']);
        $orientation = trim($_POST['orientation']);
        $audience = trim($_POST['audience']);
    
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dss";
    
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
        $sql = "SELECT 
                    media.id, 
                    media.filename, 
                    media.filetype, 
                    media.ogname, 
                    media.orientation, 
                    media.audience, 
                    audience.type, 
                    media.userid 
                FROM 
                    media 
                INNER JOIN 
                    audience 
                ON 
                    media.audience = audience.id
                WHERE 
                    media.status = '1' 
                AND media.userid = '$userID' 
                AND media.orientation = '$orientation' 
                AND media.audience = '$audience'
                LIMIT 1;";
        
        $result = $conn->query($sql);
    
        $data = [];
    
        if(!empty($result) && $result->num_rows > 0){
            while($row = $result->fetch_assoc()) {
                $data = $row;
                break;
            }
        }
    
        $conn->close();
    
        return $data;
    }
    
    $media = getAllMedia();

    echo json_encode([
        'status' => 'success',
        'data' => $media
    ]);
}