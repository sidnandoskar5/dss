<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if($_POST['req-type'] === 'register'){
        registerDisplay();
    }

    if($_POST['req-type'] === 'expiry'){
        checkDisplayStatus();
    }

    if($_POST['req-type'] === 'update'){
        updateDisplay();
    }

    if($_POST['req-type'] === 'delete'){
        deleteDisplay();
    }
}

function deleteDisplay(){
    $displayId = $_POST['displayid'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE display SET status=0 WHERE id=$displayId";
    $status = $conn->query($sql);
    $conn->close();
    return $status;
}


function updateDisplay(){
    $displayId = $_POST['displayid'];
    $displayname = $_POST['newDisplayName'];
    $orientation = $_POST['orientation'];
    $status = $_POST['status'];
    $userid = $_POST['userid'];

    if(!checkDuplicateName($displayname, $userid, $displayId)){
        echo json_encode([
            'status' => false,
            'message' => 'This display name is already in use.'
        ]);

        exit(0);
    }

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE display SET name='$displayname', orientation='$orientation', status='$status' WHERE id=$displayId";
    $status = $conn->query($sql);
    $conn->close();

    echo json_encode([
        'status' => true,
        'message' => 'Display updated successfully.'
    ]);

    exit(0);

}

function checkDisplayStatus(){
    $displayId = $_POST['displayId'];
    $userId = $_POST['uid'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT id 
            FROM display
            WHERE id=$displayId AND userid=$userId AND status=1";
    $result = $conn->query($sql);

    $conn->close();

    if($result->num_rows > 0){
        echo json_encode([
            'status' => true
        ]);
    }else{
        echo json_encode([
            'status' => false
        ]);
    }
}


function registerDisplay(){
    $uname = clean($_POST['uname']);
    $pass = clean($_POST['pswd']);
    $dispname = clean($_POST['dispname']);
    $orientation = clean($_POST['orientation']);
    $displaykey = clean($_POST['displaykey']);

    $userData = checkUser($uname, $pass);

    if(empty($userData)){
        echo json_encode([
            'status' => false,
            'message' => 'Error: Credentials does not match.'
        ]);

        exit(0);
    }

    if(!checkDuplicateName($dispname, $userData['id'], 0)){
        echo json_encode([
            'status' => false,
            'message' => 'This display name is already in use.'
        ]);

        exit(0);
    }

    $displayData = addDisplay($dispname, $userData['id'], $displaykey, $orientation);

    if(!empty($displayData)){
        echo json_encode([
            'status' => true,
            'message' => 'Display added successfully.',
            'data' => $displayData
        ]);

        exit(0);
    }else{
        echo json_encode([
            'status' => false,
            'message' => 'Failed to add display.',
        ]);

        exit(0);
    }
}

function clean($input){
    return trim($input);
}

function checkUser($uname, $pass){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT id, username, email FROM user WHERE username='$uname' AND password ='" . MD5($pass) . "'";
    $result = $conn->query($sql);

    $userData = [];

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()) {
            $userData = [
                'id' => $row['id'],
                'username' => $row['username'],
                'email' => $row['email']
            ];
        }
    }

    $conn->close();

    return $userData;
}

function checkDuplicateName($displayname, $userId, $displayId = 0){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * 
            FROM display 
            WHERE 
                name='$displayname' 
                AND userid=$userId
                AND id != $displayId
                AND status=1";
            
    $result = $conn->query($sql);

    $conn->close();

    if($result->num_rows > 0){
        return false;
    }

    return true;
}

function addDisplay($dispname, $userId, $displaykey, $orientation){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dss";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $displayUrl = "/?p=display_op&d_name=$dispname&key=$displaykey&udi=$userId&ort=$orientation";

    try{
        $sql = "INSERT INTO display(name, userid, displaykey, displayurl, orientation)
        VALUES ('$dispname', '$userId', '$displaykey', '$displayUrl', '$orientation')";
        
        if ($conn->query($sql) === TRUE) {
            $last_id = $conn->insert_id;
            return [
                'id' => $last_id,
                'url' => $displayUrl,
                'displaykey' => $displaykey
            ];
        } else {
            return [];
            $error = "Error: " . $conn->error;
        }
    }catch(Exception $err){
        $error = "Error: " . $err->getMessage();
    }
}