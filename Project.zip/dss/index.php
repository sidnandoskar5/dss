<?php 
    session_start(); 
    require_once("functions.php"); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="./assets/js/jquery.min.js"></script>

    <link rel="stylesheet" href="./assets/css/bootstrap5.css">
    <script src="./assets/js/bootstrap5.js"></script>
    
    <link rel="stylesheet" href="./assets/css/bootstrap3.css">
    <script src="./assets/js/bootstrap3.js"></script>
    
    <link rel="stylesheet" href="./assets/css/style.css?v=1">

    <title>DSS - Digital Signage System</title>
</head>
<body>
    <main>
    <?php 
        if(!empty($_SESSION['user']) && !empty($_GET['p']) && !in_array($_GET['p'],['register_display','display_op','login','register','forgot'])){
            echo element('header'); 
        }
    ?>
    <?php if(!empty($_SESSION['user']) && !empty($_GET['p']) && !in_array($_GET['p'],['login','register','forgot', 'register_display','display_op'])){ ?>
        <div class="section-wrapper clearfix">
            <aside class="sm-content">
                <?php echo element('menu'); ?>
            </aside>
            <div class="lg-content">
                <?php fetch(); ?>
            </div>
        </div>
    <?php } else{
        fetch(); 
    } ?>
    <?php echo element('footer'); ?>
    </main>
</body>
</html>