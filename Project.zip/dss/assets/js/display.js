$(document).ready(function(){
    var flag = true;
    const displayname = $("#display-info").data('displayname'),
    displaykey = $("#display-info").data('displaykey'),
    user = $("#display-info").data('user'),
    orientation = $("#display-info").data('orientation');

    const localInfo = JSON.parse(localStorage.getItem('dispinfo'));

    if(localInfo && displaykey == localInfo.displaykey && localInfo.status == 1){
        const video = document.getElementById('video');
        Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri('/dss/assets/js/models'),
            faceapi.nets.faceLandmark68Net.loadFromUri('/dss/assets/js/models'),
            faceapi.nets.faceRecognitionNet.loadFromUri('/dss/assets/js/models'),
            faceapi.nets.faceExpressionNet.loadFromUri('/dss/assets/js/models'),
            faceapi.nets.ageGenderNet.loadFromUri('/dss/assets/js/models')
        ]).then(startVideo)

        async function startVideo() {
            camera_stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            video.srcObject = camera_stream;
        }

        video.addEventListener('play', () => {
            const canvas = faceapi.createCanvasFromMedia(video)
            document.body.append(canvas)
            const displaySize = { width: video.width, height: video.height }
            faceapi.matchDimensions(canvas, displaySize)
            detectAd(video, faceapi);
        })
    }else{
        $("#err-overlay").addClass('active').html("<span class='error'>Invalid Display!</span>");
    }

    const detectAd = async (video, faceapi) => {
        const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withAgeAndGender();
        var $gender = '';
        var $age = '';
        if(detections[0] !== undefined){
            $gender = detections[0].gender;
            $("#gender").html($gender);

            $age = detections[0].age.toFixed(2);
            $("#age").html($age);

            let audience = '';
            if($gender === 'male'){
                if($age > 20){
                    audience = 2
                }else{
                    audience = 4
                }
            }else if($gender === 'female'){
                if($age > 20){
                    audience = 3
                }else{
                    audience = 5
                }
            }else{
                audience = 1
            }

            let userId = user;
            let ort = orientation;

            console.log({audience, userId, orientation:ort});

            $.post("/dss/util/display_op.php",
                {audience, userId, orientation:ort},
                function(data, status){
                    let udata = JSON.parse(data);
                    if(udata.status){
                        const newData = udata.data,
                        audi = newData.type,
                        orient = newData.orientation,
                        file = `uploads/${newData.ogname}.${newData.filetype}`;

                        $('#audience #tval').text(audi);
                        $('#orientation #tval').text(orient);
                        $("#ed img").attr('src', file);
                        setTimeout(() => {detectAd(video, faceapi)},10000);
                    }
                }
            );
        }else{
            detectAd(video, faceapi);
        }
    }
});