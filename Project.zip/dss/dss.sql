-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2023 at 03:19 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dss`
--

-- --------------------------------------------------------

--
-- Table structure for table `audience`
--

CREATE TABLE `audience` (
  `id` int(20) NOT NULL,
  `type` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `audience`
--

INSERT INTO `audience` (`id`, `type`) VALUES
(1, 'all'),
(2, 'men'),
(3, 'women'),
(4, 'boys'),
(5, 'girls');

-- --------------------------------------------------------

--
-- Table structure for table `display`
--

CREATE TABLE `display` (
  `id` bigint(20) NOT NULL,
  `name` varchar(60) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `displaykey` bigint(60) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `displayurl` varchar(255) NOT NULL,
  `orientation` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `display`
--

INSERT INTO `display` (`id`, `name`, `userid`, `displaykey`, `status`, `displayurl`, `orientation`) VALUES
(1, 'chrome personal', 1, 9039056437, 1, '/?p=display_op&d_name=chrome personal&key=9039056437&udi=1&ort=landscape', 'landscape'),
(2, 'Edge Display', 1, 1916172696, 1, '/?p=display_op&d_name=Edge Display&key=1916172696&udi=1&ort=landscape', 'landscape');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) NOT NULL,
  `filename` varchar(60) NOT NULL,
  `filetype` varchar(20) NOT NULL,
  `audience` varchar(255) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `orientation` varchar(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `ogname` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `filename`, `filetype`, `audience`, `userid`, `orientation`, `status`, `ogname`) VALUES
(1, 'contact person', 'jpg', '1', 1, 'landscape', 0, 'customer_support'),
(2, 'Playstation', 'jpg', '1', 1, 'landscape', 1, 'PS'),
(3, 'Car', 'jpg', '2', 1, 'landscape', 1, 'car'),
(4, 'neckless', 'jpg', '3', 1, 'landscape', 1, 'neck'),
(5, 'naruto', 'jpg', '4', 1, 'landscape', 1, 'nar'),
(6, 'barbie', 'jpg', '5', 1, 'landscape', 1, '547479-barbie-wallpapers');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `registration_date`, `status`) VALUES
(1, 'gaurang', 'gaurang@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2023-04-20 01:51:27', 1),
(2, 'root', '', '', '2023-04-20 03:39:18', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audience`
--
ALTER TABLE `audience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `display`
--
ALTER TABLE `display`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audience`
--
ALTER TABLE `audience`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `display`
--
ALTER TABLE `display`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
