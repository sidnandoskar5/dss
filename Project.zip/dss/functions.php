<?php

global $conn;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dss";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

function element($fileName, $variables = []){
	ob_start();
	extract($variables);
	if (strpos($fileName, '.php') === false) {
		$fileName .= '.php';
	}
	include("elements/$fileName");
	return ob_get_clean();
}

function fetch(){
    // $page = (!empty($_GET['p']) && !empty($_SESSION['user'])) ? $_GET['p'] : "login";
    $page = "login";
    if(!empty($_GET['p'])){
        if(!in_array($_GET['p'], ['register_display', 'display_op', 'login', 'register', 'forgot'])){
            if(!empty($_SESSION['user'])){
                $page = $_GET['p'];
            }
        }else{
            $page = $_GET['p'];
        }
    }

    $pagePath = "pages/{$page}.php";

    clearstatcache();
    if(!file_exists($pagePath)){
        $pagePath = "pages/400.php";
    }
    
    include($pagePath);
}

function pr($data){
    echo "<pre>" . print_r($data, true) . "</pre>";
}